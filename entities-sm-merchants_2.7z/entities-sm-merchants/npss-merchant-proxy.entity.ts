import { Column, Entity, Index, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { NpssMerchantAccounts } from "./npss-merchant-accounts.entity";
import { NpssMerchantShops } from "./npss-merchant-shops.entity";

@Index("npss_merchant_proxy_pkey", ["npssmpId"], { unique: true })
@Entity("npss_merchant_proxy", { schema: "ad_gss_tran" })
export class NpssMerchantProxy {
  @PrimaryGeneratedColumn({ type: "integer", name: "npssmp_id" })
  npssmpId: number;

  @Column("character varying", {
    name: "product_code",
    nullable: true,
    length: 16,
  })
  productCode: string | null;

  @Column("character varying", { name: "bankuserid", length: 16 })
  bankuserid: string;

  // @OneToMany(() => NpssMerchantShops, (NpssMerchantShops) => NpssMerchantShops.Proxy,
  //   { eager: true, cascade: true })
  //   Shops: NpssMerchantShops[]

  //   @OneToMany(() => NpssMerchantAccounts, (NpssMerchantAccounts) => NpssMerchantAccounts.Proxy,
  //   { eager: true, cascade: true })
  //   Account: NpssMerchantAccounts[]

  @Column("character varying", {
    name: "group_code",
    nullable: true,
    length: 5,
  })
  groupCode: string | null;

  @Column("character varying", { name: "bank_code", nullable: true, length: 5 })
  bankCode: string | null;

  @Column("character varying", {
    name: "merchant_tag",
    nullable: true,
    length: 8,
  })
  merchantTag: string | null;

  @Column("character varying", {
    name: "merchant_name",
    nullable: true,
    length: 50,
  })
  merchantName: string | null;

  @Column("character varying", { name: "surname", nullable: true, length: 50 })
  surname: string | null;

  @Column("character varying", { name: "denomination", length: 100 })
  denomination: string;

  @Column("character varying", { name: "vat_number", length: 20 })
  vatNumber: string;

  @Column("character varying", { name: "mcc", length: 4 })
  mcc: string;

  @Column("character varying", { name: "mobile", length: 30 })
  mobile: string;

  @Column("character varying", {
    name: "proxy_type",
    nullable: true,
    length: 50,
  })
  proxyType: string | null;

  @Column("character varying", {
    name: "proxy_value",
    nullable: true,
    length: 50,
  })
  proxyValue: string | null;

  @Column("character varying", { name: "email", nullable: true, length: 50 })
  email: string | null;

  @Column("character varying", {
    name: "document_id",
    nullable: true,
    length: 50,
  })
  documentId: string | null;

  @Column("character varying", {
    name: "channel_name",
    nullable: true,
    length: 100,
  })
  channelName: string | null;

  @Column("character varying", { name: "logo", nullable: true, length: 4000 })
  logo: string | null;

  @Column("integer", { name: "exhf_id", nullable: true })
  exhfId: number | null;

  

  @Column("character varying", {
    name: "channel_id",
    nullable: true,
    length: 128,
  })
  channelId: string | null;

  @Column("character varying", {
    name: "channel_userid",
    nullable: true,
    length: 128,
  })
  channelUserid: string | null;

  @Column("character varying", {
    name: "channel_product",
    nullable: true,
    length: 128,
  })
  channelProduct: string | null;

  @Column("character varying", {
    name: "channel_sub_product",
    nullable: true,
    length: 128,
  })
  channelSubProduct: string | null;

  @Column("character varying", {
    name: "channel_tran_code",
    nullable: true,
    length: 3,
  })
  channelTranCode: string | null;

  @Column("character varying", {
    name: "channel_refno",
    nullable: true,
    length: 128,
  })
  channelRefno: string | null;

  @Column("character varying", { name: "created_by", length: 256 })
  createdBy: string;

  @Column("character varying", {
    name: "created_by_name",
    nullable: true,
    length: 256,
  })
  createdByName: string | null;

  @Column("timestamp without time zone", { name: "created_date" })
  createdDate: Date;

  @Column("character varying", {
    name: "modified_by",
    nullable: true,
    length: 256,
  })
  modifiedBy: string | null;

  @Column("character varying", {
    name: "modified_by_name",
    nullable: true,
    length: 256,
  })
  modifiedByName: string | null;

  @Column("timestamp without time zone", {
    name: "modified_date",
    nullable: true,
  })
  modifiedDate: Date | null;

  @Column("character varying", {
    name: "system_id",
    nullable: true,
    length: 256,
  })
  systemId: string | null;

  @Column("character varying", {
    name: "system_name",
    nullable: true,
    length: 256,
  })
  systemName: string | null;

  @Column("character varying", { name: "prct_id", nullable: true, length: 256 })
  prctId: string | null;

  @Column("character varying", {
    name: "created_by_sts_id",
    nullable: true,
    length: 256,
  })
  createdByStsId: string | null;

  @Column("character varying", {
    name: "modified_by_sts_id",
    nullable: true,
    length: 256,
  })
  modifiedByStsId: string | null;

  @Column("character varying", { name: "status", nullable: true, length: 256 })
  status: string | null;

  @Column("character varying", {
    name: "process_status",
    nullable: true,
    length: 256,
  })
  processStatus: string | null;

  @Column("character varying", { name: "dt_code", nullable: true, length: 256 })
  dtCode: string | null;

  @Column("character varying", {
    name: "dt_description",
    nullable: true,
    length: 256,
  })
  dtDescription: string | null;

  @Column("character varying", {
    name: "dtt_code",
    nullable: true,
    length: 256,
  })
  dttCode: string | null;

  @Column("character varying", {
    name: "dtt_description",
    nullable: true,
    length: 256,
  })
  dttDescription: string | null;

  @Column("character varying", { name: "app_id", nullable: true, length: 256 })
  appId: string | null;

  @Column("character varying", {
    name: "routingkey",
    nullable: true,
    length: 256,
  })
  routingkey: string | null;

  @Column("character varying", {
    name: "created_clientip",
    nullable: true,
    length: 256,
  })
  createdClientip: string | null;

  @Column("character varying", {
    name: "created_tz",
    nullable: true,
    length: 256,
  })
  createdTz: string | null;

  @Column("character varying", {
    name: "created_tz_offset",
    nullable: true,
    length: 256,
  })
  createdTzOffset: string | null;

  @Column("character varying", {
    name: "created_by_sessionid",
    nullable: true,
    length: 512,
  })
  createdBySessionid: string | null;

  @Column("character varying", {
    name: "modified_clientip",
    nullable: true,
    length: 256,
  })
  modifiedClientip: string | null;

  @Column("character varying", {
    name: "modified_tz",
    nullable: true,
    length: 256,
  })
  modifiedTz: string | null;

  @Column("character varying", {
    name: "modified_tz_offset",
    nullable: true,
    length: 256,
  })
  modifiedTzOffset: string | null;

  @Column("character varying", {
    name: "modified_by_sessionid",
    nullable: true,
    length: 512,
  })
  modifiedBySessionid: string | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date1",
    nullable: true,
  })
  fxResvDate1: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date2",
    nullable: true,
  })
  fxResvDate2: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date3",
    nullable: true,
  })
  fxResvDate3: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date4",
    nullable: true,
  })
  fxResvDate4: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date5",
    nullable: true,
  })
  fxResvDate5: Date | null;

  @Column("character varying", {
    name: "fx_resv_text1",
    nullable: true,
    length: 256,
  })
  fxResvText1: string | null;

  @Column("character varying", {
    name: "fx_resv_text2",
    nullable: true,
    length: 256,
  })
  fxResvText2: string | null;

  @Column("character varying", {
    name: "fx_resv_text3",
    nullable: true,
    length: 256,
  })
  fxResvText3: string | null;

  @Column("character varying", {
    name: "fx_resv_text4",
    nullable: true,
    length: 256,
  })
  fxResvText4: string | null;

  @Column("character varying", {
    name: "fx_resv_text5",
    nullable: true,
    length: 256,
  })
  fxResvText5: string | null;

  @Column("timestamp without time zone", {
    name: "created_date_utc",
    nullable: true,
  })
  createdDateUtc: Date | null;

  @Column("timestamp without time zone", {
    name: "modified_date_utc",
    nullable: true,
  })
  modifiedDateUtc: Date | null;

  @Column("integer", { name: "version_no", nullable: true, default: () => "0" })
  versionNo: number | null;

  @Column("character varying", {
    name: "tenant_id",
    nullable: true,
    length: 256,
  })
  tenantId: string | null;

  @Column("character varying", { name: "ai_id", nullable: true, length: 256 })
  aiId: string | null;
}
