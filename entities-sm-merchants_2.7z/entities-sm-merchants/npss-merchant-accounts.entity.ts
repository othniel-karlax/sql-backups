import { Column, Entity, Index, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { NpssMerchantProxy } from "./npss-merchant-proxy.entity";

@Index("npss_merchant_accounts_pkey", ["npssmaId"], { unique: true })
@Entity("npss_merchant_accounts", { schema: "ad_gss_tran" })
export class NpssMerchantAccounts {
  @PrimaryGeneratedColumn({ type: "integer", name: "npssma_id" })
  npssmaId: number;

  @Column("character varying", {
    name: "product_code",
    nullable: true,
    length: 16,
  })
  productCode: string | null;

  @Column("character varying", { name: "bankuserid", length: 16 })
  bankuserid: string;

  // @ManyToOne(() => NpssMerchantProxy, (NpssMerchantProxy) => NpssMerchantProxy.Account)
    // @JoinColumn({ name: 'npssms_id', referencedColumnName: 'npssms_id' })
    // Proxy: NpssMerchantProxy

  @Column("character varying", { name: "npssmp_id", length: 16 })
  Npssmp_id: string;

  @Column("character varying", { name: "iban", length: 35 })
  iban: string;

  @Column("character varying", { name: "currency", nullable: true, length: 3 })
  currency: string | null;

  @Column("character varying", {
    name: "default_account",
    nullable: true,
    length: 5,
  })
  defaultAccount: string | null;

  @Column("integer", { name: "exhf_id", nullable: true })
  exhfId: number | null;

  // @Column("character varying", {
  //   name: "channel_id",
  //   nullable: true,
  //   length: 128,
  // })
  // channelId: string | null;

  // @Column("character varying", {
  //   name: "channel_userid",
  //   nullable: true,
  //   length: 128,
  // })
  // channelUserid: string | null;
  // @Column("character varying", {
  //   name: "channel_refno",
  //   nullable: true,
  //   length: 128,
  // })
  // channelRefno: string | null;

  @Column("character varying", { name: "created_by", length: 256 })
  createdBy: string;

  @Column("character varying", {
    name: "created_by_name",
    nullable: true,
    length: 256,
  })
  createdByName: string | null;

  @Column("timestamp without time zone", { name: "created_date" })
  createdDate: Date;

  @Column("character varying", {
    name: "modified_by",
    nullable: true,
    length: 256,
  })
  modifiedBy: string | null;

  @Column("character varying", {
    name: "modified_by_name",
    nullable: true,
    length: 256,
  })
  modifiedByName: string | null;

  @Column("timestamp without time zone", {
    name: "modified_date",
    nullable: true,
  })
  modifiedDate: Date | null;

  @Column("character varying", {
    name: "system_id",
    nullable: true,
    length: 256,
  })
  systemId: string | null;

  @Column("character varying", {
    name: "system_name",
    nullable: true,
    length: 256,
  })
  systemName: string | null;

  @Column("character varying", { name: "prct_id", nullable: true, length: 256 })
  prctId: string | null;

  @Column("character varying", {
    name: "created_by_sts_id",
    nullable: true,
    length: 256,
  })
  createdByStsId: string | null;

  @Column("character varying", {
    name: "modified_by_sts_id",
    nullable: true,
    length: 256,
  })
  modifiedByStsId: string | null;

  @Column("character varying", { name: "status", nullable: true, length: 256 })
  status: string | null;

  @Column("character varying", {
    name: "process_status",
    nullable: true,
    length: 256,
  })
  processStatus: string | null;

  @Column("character varying", { name: "dt_code", nullable: true, length: 256 })
  dtCode: string | null;

  @Column("character varying", {
    name: "dt_description",
    nullable: true,
    length: 256,
  })
  dtDescription: string | null;

  @Column("character varying", {
    name: "dtt_code",
    nullable: true,
    length: 256,
  })
  dttCode: string | null;

  @Column("character varying", {
    name: "dtt_description",
    nullable: true,
    length: 256,
  })
  dttDescription: string | null;

  @Column("character varying", { name: "app_id", nullable: true, length: 256 })
  appId: string | null;

  @Column("character varying", {
    name: "routingkey",
    nullable: true,
    length: 256,
  })
  routingkey: string | null;

  @Column("character varying", {
    name: "created_clientip",
    nullable: true,
    length: 256,
  })
  createdClientip: string | null;

  @Column("character varying", {
    name: "created_tz",
    nullable: true,
    length: 256,
  })
  createdTz: string | null;

  @Column("character varying", {
    name: "created_tz_offset",
    nullable: true,
    length: 256,
  })
  createdTzOffset: string | null;

  @Column("character varying", {
    name: "created_by_sessionid",
    nullable: true,
    length: 512,
  })
  createdBySessionid: string | null;

  @Column("character varying", {
    name: "modified_clientip",
    nullable: true,
    length: 256,
  })
  modifiedClientip: string | null;

  @Column("character varying", {
    name: "modified_tz",
    nullable: true,
    length: 256,
  })
  modifiedTz: string | null;

  @Column("character varying", {
    name: "modified_tz_offset",
    nullable: true,
    length: 256,
  })
  modifiedTzOffset: string | null;

  @Column("character varying", {
    name: "modified_by_sessionid",
    nullable: true,
    length: 512,
  })
  modifiedBySessionid: string | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date1",
    nullable: true,
  })
  fxResvDate1: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date2",
    nullable: true,
  })
  fxResvDate2: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date3",
    nullable: true,
  })
  fxResvDate3: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date4",
    nullable: true,
  })
  fxResvDate4: Date | null;

  @Column("timestamp without time zone", {
    name: "fx_resv_date5",
    nullable: true,
  })
  fxResvDate5: Date | null;

  @Column("character varying", {
    name: "fx_resv_text1",
    nullable: true,
    length: 256,
  })
  fxResvText1: string | null;

  @Column("character varying", {
    name: "fx_resv_text2",
    nullable: true,
    length: 256,
  })
  fxResvText2: string | null;

  @Column("character varying", {
    name: "fx_resv_text3",
    nullable: true,
    length: 256,
  })
  fxResvText3: string | null;

  @Column("character varying", {
    name: "fx_resv_text4",
    nullable: true,
    length: 256,
  })
  fxResvText4: string | null;

  @Column("character varying", {
    name: "fx_resv_text5",
    nullable: true,
    length: 256,
  })
  fxResvText5: string | null;

  @Column("timestamp without time zone", {
    name: "created_date_utc",
    nullable: true,
  })
  createdDateUtc: Date | null;

  @Column("timestamp without time zone", {
    name: "modified_date_utc",
    nullable: true,
  })
  modifiedDateUtc: Date | null;

  @Column("integer", { name: "version_no", nullable: true, default: () => "0" })
  versionNo: number | null;

  @Column("character varying", {
    name: "tenant_id",
    nullable: true,
    length: 256,
  })
  tenantId: string | null;

  @Column("character varying", { name: "ai_id", nullable: true, length: 256 })
  aiId: string | null;
}
